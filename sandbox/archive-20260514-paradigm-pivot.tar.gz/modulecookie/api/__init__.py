"""modulecookie API routers."""
